const express = require("express");
const axios = require("axios");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const API_KEY = "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";

app.post("/api/chat", async (req, res) => {
  try {
    const response = await axios.post(
      "https://api.openai.com/v1/chat/completions",
      req.body,
      {
        headers: {
          "Authorization": `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
      }
    );
    res.json(response.data);
  } catch (error) {
    console.error(error);
    res.status(500).send("Error communicating with OpenAI API");
  }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
