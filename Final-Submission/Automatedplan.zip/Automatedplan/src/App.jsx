import React, { useState, useEffect } from "react";
import "./App.css";
import "@chatscope/chat-ui-kit-styles/dist/default/styles.min.css";
import {
  MainContainer,
  ChatContainer,
  MessageList,
  Message,
  MessageInput,
  TypingIndicator,
} from "@chatscope/chat-ui-kit-react";

const API_KEY = "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"; 

function App() {
  const [placeholderText, setPlaceholderText] = useState("Type your response here");
  const [parsedCourses, setParsedCourses] = useState(null);
  const [takenCourses, setTakenCourses] = useState(null);
  const [typing, setTyping] = useState(false);
  const [messages, setMessages] = useState([
    {
      message: `Hello :) I am the EasyEnroll AI 
      Let me know what you need help with:

      a) Generate Generic Plan
      b) Generate Plan with your preferences
      `,
      sender: "ChatGPT",
    },
  ]);

  useEffect(() => {
    // Load JSON files
    const fetchFiles = async () => {
      try {
        const coursesResponse = await fetch("/data/courses.json");
        const takenCoursesResponse = await fetch("/data/takenCourses.json");

        const coursesData = await coursesResponse.json();
        const takenCoursesData = await takenCoursesResponse.json();

        setParsedCourses(coursesData);
        setTakenCourses(takenCoursesData);

        console.log("Courses Loaded:", coursesData);
        console.log("Taken Courses Loaded:", takenCoursesData);
      } catch (error) {
        console.error("Error loading JSON files:", error);
      }
    };

    fetchFiles();
  }, []);

  const handleSend = async (message) => {
    const newMessage = {
      message: message,
      sender: "user",
      direction: "outgoing",
    };

    const newMessages = [...messages, newMessage];
    setMessages(newMessages);

    // Pass the user's input to OpenAI
    await generateResponse(message);
  };

  const generateResponse = async (userMessage) => {
    setTyping(true);

    const prompt = `
You are an academic advisor AI. Below are details from two JSON files: 
1. A list of all courses with their prerequisites and concurrent requirements (JSON: courses).
2. A list of courses already taken by a specific student, including their username (JSON: takenCourses).

The user has written: "${userMessage}"

Your Tasks:
1. For titles, use plain text with appropriate capitalization or formatting (NO SYMBOLS OR BOLD)
2. Respond based on the user's input appropriately. 
3. Follow these credit hour guidelines:
   - Minimum credit hours per semester: 12.
   - Maximum credit hours per semester: 18 (up to 20 credit hours allowed for overloading). 
4. Display only course names and total credit hours unless the user specifies otherwise.
5. Handle user inputs as follows:
   - Input 'a': Generate a one-semester generic course plan.
   - Input 'b': Prompt the user for preferences, which include: 
     - Desired credit hours 
     - Preference for labs or no labs.
     - Number of semester plans to generate.
     - Any could be null and you still generate
6. Generate a course plan based on user input:
   - For "generic plan" or equivalent: Create a one-semester plan based on default data.
   - For provided preferences: Use the preferences to generate a tailored plan.
7. For unrelated inputs, respond appropriately based on the input context.

JSON Data (courses):
${JSON.stringify(parsedCourses)}

JSON Data (takenCourses):
${JSON.stringify(takenCourses)}
`;

    const apiRequestBody = {
      model: "gpt-4o-mini",
      messages: [
        { role: "system", content: "You are an academic advisor AI." },
        { role: "user", content: prompt },
      ],
      temperature: 0.5,
      max_tokens: 1000,
    };

    try {
      const response = await fetch("https://api.openai.com/v1/chat/completions", {
        method: "POST",
        headers: {
          Authorization: `Bearer ${API_KEY}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify(apiRequestBody),
      });

      if (!response.ok) {
        throw new Error(`API Error: ${response.statusText}`);
      }

      const data = await response.json();
      const chatGPTMessage = {
        message: data.choices[0].message.content.trim(),
        sender: "ChatGPT",
      };

      setMessages((prevMessages) => [...prevMessages, chatGPTMessage]);
    } catch (error) {
      console.error("Error:", error);
      setMessages((prevMessages) => [
        ...prevMessages,
        {
          message: "There was an error processing your request. Please try again.",
          sender: "ChatGPT",
        },
      ]);
    } finally {
      setTyping(false);
    }
  };

  return (
    <div>
      <div style={{ position: "relative", height: "600px", width: "700px" }}>
        <MainContainer>
          <ChatContainer>
          <MessageList
  className="chat-messages"
  typingIndicator={
    typing ? (
      <TypingIndicator content="EasyEnroll AI is typing..." className="typing-indicator" />
    ) : null
  }
>
  {messages.map((message, i) => (
    <Message
      key={i}
      model={{
        message: message.message,
        sentTime: "just now",
        sender: message.sender,
        direction: message.sender === "user" ? "outgoing" : "incoming",
      }}
      className="chat-message"
    />
  ))}
</MessageList>
<MessageInput
              className="message-input"
              onSend={handleSend}
              onFocus={() => setPlaceholderText("")}
              onBlur={() => setPlaceholderText("Type your response here")}
            />

          </ChatContainer>
        </MainContainer>
      </div>
    </div>
  );
}

export default App;
