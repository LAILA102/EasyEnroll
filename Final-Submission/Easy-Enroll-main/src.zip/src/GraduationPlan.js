// src/components/GraduationPlan.js

import React, { useState } from "react";
import "./Graduationplan.css";

import {
  Container,
  Typography,
  Button,
  CircularProgress,
  Alert,
  Paper,
  List,
  ListItem,
  ListItemText,
  TextField,
  Box,
  Grid,
} from "@mui/material";

function GraduationPlan() {
  const [plan, setPlan] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState(null);

  const [student1, setStudent1] = useState("");
  const [student2, setStudent2] = useState("");

  const generatePlan = async () => {
    setLoading(true);
    setError(null);
    setPlan(null);
    try {
      const response = await fetch("http://localhost:1900/api/generate-plan", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          students: [student1.trim(), student2.trim()],
        }),
      });
      const data = await response.json();
      if (response.ok) {
        setPlan(data.plan);
      } else {
        setError(data.error || "Failed to generate plan");
      }
    } catch (e) {
      console.error("Error during fetch:", e);
      setError("Failed to generate plan");
    } finally {
      setLoading(false);
    }
  };

  const renderPlan = () => {
    if (!plan) return null;

    return (
      <Box
        sx={{
          maxHeight: "500px",
          overflowY: "auto",
          marginTop: "16px",
        }}
      >
        {Object.entries(plan).map(([student, semesters]) => (
          <Paper key={student} sx={{ padding: "16px", marginBottom: "16px" }}>
            <Typography variant="h6">{student}'s Plan</Typography>
            {renderSemesters(semesters)}
          </Paper>
        ))}
      </Box>
    );
  };

  const renderSemesters = (semesters) => {
    return (
      <Grid container spacing={2} sx={{ marginTop: "16px" }}>
        {Object.entries(semesters).map(([semester, courses]) => (
          <Grid item xs={12} sm={6} md={4} key={semester}>
            <Paper sx={{ padding: "8px" }}>
              <Typography variant="subtitle1">{semester}</Typography>
              <List dense>
                {courses.map((course) => (
                  <ListItem key={course}>
                    <ListItemText primary={course} />
                  </ListItem>
                ))}
              </List>
            </Paper>
          </Grid>
        ))}
      </Grid>
    );
  };

  return (
    <Container maxWidth="md">
      <Typography variant="h4" gutterBottom>
        Graduation Plan
      </Typography>
      <TextField
        label="Student 1 Username"
        value={student1}
        onChange={(e) => setStudent1(e.target.value)}
        variant="outlined"
        fullWidth
        margin="normal"
      />
      <TextField
        label="Student 2 Username"
        value={student2}
        onChange={(e) => setStudent2(e.target.value)}
        variant="outlined"
        fullWidth
        margin="normal"
      />
      <Button
        variant="contained"
        color="primary"
        onClick={generatePlan}
        disabled={loading || !student1 || !student2}
        sx={{ marginTop: "16px" }}
      >
        {loading ? "Generating Plan..." : "Generate Graduation Plan"}
      </Button>
      {loading && (
        <Box sx={{ marginTop: "16px" }}>
          <CircularProgress />
        </Box>
      )}
      {error && (
        <Alert severity="error" sx={{ marginTop: "16px" }}>
          {error}
        </Alert>
      )}
      {plan && renderPlan()}
    </Container>
  );
}

export default GraduationPlan;
