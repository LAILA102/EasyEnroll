const express = require('express');
const bodyParser = require('body-parser');
const cors = require('cors');
const { OpenAI } = require("openai");
const fs = require('fs');
const path = require('path');

// Initialize Express app
const app = express();
app.use(cors());
app.use(bodyParser.json());

// Initialize OpenAI with the API key (make sure to keep this secure)
const openai = new OpenAI({
    apiKey: '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',
});

// Set paths for the three .json files (adjust paths as necessary)
const jsonFiles = [
    path.join("D:\\EasyEnroll-main\\src\\data\\courses.json"),
    path.join("D:\\EasyEnroll-main\\src\\data\\takenCourses.json"),
    path.join("D:\\EasyEnroll-main\\src\\data\\Sections.json")
];

// Function to read JSON files
const readJSONFile = (filePath) => {
    try {
        const data = fs.readFileSync(filePath, 'utf8');
        return JSON.parse(data);
    } catch (error) {
        console.error('Error reading JSON file:', error);
        return null;
    }
};

// API route for handling OpenAI requests
app.post('/api/openai', async (req, res) => {
    try {
        // Read content from all three JSON files
        const fileContents = jsonFiles.map(filePath => readJSONFile(filePath));

        // Combine the JSON contents into one prompt
        const prompt = `
            Based on the following data, generate a response:
            Courses: ${JSON.stringify(fileContents[0])}
            Taken Courses: ${JSON.stringify(fileContents[1])}
            Sections: ${JSON.stringify(fileContents[2])}
            Now, respond to the following prompt:
            ${req.body.prompt}
        `;
        
        // Generate OpenAI response
        const response = await openai.chat.completions.create({
            model: "gpt-4o-mini",
            messages: [{ role: 'user', content: prompt }],
            temperature: 0.3,
            max_tokens: 1000,
        });

        // Send back the response from OpenAI
        if (response.choices && response.choices.length > 0) {
            res.json({ text: response.choices[0].message.content });
        } else {
            res.status(500).json({ error: 'No response from OpenAI' });
        }
    } catch (error) {
        console.error(error.message);
        res.status(500).json({ error: "An error occurred: " + error.message });
    }
});

// Serve static files from the 'build' folder (React app)
app.use(express.static(path.join(__dirname, '..', 'build')));

// Define a route for '/manual-plan' to serve a specific React page (adjust as needed)
app.get('/manual-plan', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'build', 'ManualPlanPage.js'));
});

// Define a route for '/manual-plan' to serve a specific React page (adjust as needed)
app.get('/Schedule', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'build', 'Schedule.js'));
});

// Serve index.html when visiting the root route
app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, '..', 'build', 'index.html'));
});

// Set the port for the server
const PORT = process.env.PORT || 5000;  // Default to 5000 or use a port from environment variables
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});
