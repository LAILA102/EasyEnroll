import React, { useState, useEffect } from 'react';
import axios from 'axios';

const Schedule = () => {
    const [response, setResponse] = useState('');
    const [error, setError] = useState(''); // For error message

    useEffect(() => {
        const fetchSchedule = async () => {
            setError(''); // Clear previous error
            const prompt = `
*You are an academic advisor AI. Below are details from two JSON files:
1. A list of all courses with their prerequisites and concurrent requirements (JSON: Courses).
2. A list of courses already taken by a specific student, including their username (JSON: Taken Courses).
3. A list of all the sections available for all courses that are offered in the next semester, Spring 2025 (JSON: Sections).

Your task:
- Extract the relevant details for each course: "course name", "prereq", "prereq or concurrent", and "concurrent" and make sure to NOT display this to the user. 
- Identify courses the student is eligible to take, based on their previously completed courses and the prerequisites, and make sure to NOT display this to the user.
- For every course with a "prereq" or "concurrent" or "prereq or concurrent" ALWAYS ensure that the generated schedule includes the courses UNLESS the student has previously completed it and make sure to NOT display this to the user.
- Generate a semester schedule for spring 2025 for the student, ensuring a smooth progression toward graduation. Make sure that the courses you choose are offered in spring 2025 and that the timings do not clash. Make the schedule based on the courses, days, timings, prerequisites, concurrent courses, and taken courses.
- In the sections, U stands for Sunday, M is for Monday, T is for Tuesday, W is for Wednesday, R is for Thursday. WU is for courses that are taken on both Sunday and Wednesday, and MR is for courses that are taken both Monday and Thursday.
- This plan is complied of a minimum of 12 cr or a maximum of 18 cr.
- If no required courses fit, recommend electives that align with the major.
- ONLY display the final Course names, the CRN, the section number, the days, the time, the instructor, and the location.
- Display this info in a form of a schedule.
            `;

            try {
                const res = await axios.post('http://localhost:5000/api/openai', { prompt });
                if (res.data.text) {
                    setResponse(res.data.text); // Show OpenAI's response text
                } else {
                    setError('No response from OpenAI'); // Handle case where no text is returned
                }
            } catch (error) {
                console.error("Error:", error);
                setError('An error occurred: ' + (error.response?.data?.error || error.message)); // Show error message
            }
        };

        fetchSchedule(); // Automatically call the function on component mount
    }, []); // Empty dependency array ensures this runs only once on mount

    return (
        <div>
            {response && (
                <div>
                    <strong>Response:</strong>
                    {/* Apply inline CSS style for smaller font size */}
                    <pre style={{ fontSize: '12px' }}>{response}</pre> 
                </div>
            )}
            {error && (
                <div style={{ color: 'red' }}>
                    <strong>Error:</strong>
                    <p>{error}</p>
                </div>
            )}
        </div>
    );
};

export default Schedule;