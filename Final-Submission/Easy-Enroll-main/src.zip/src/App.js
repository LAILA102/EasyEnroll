import { BrowserRouter as Router, Route, Routes, Navigate } from 'react-router-dom';
import ManualPlanPage from './ManualPlanPage'; // Your manual plan component
import Schedule from './Schedule'; // Your schedule component
import Login from './Login'; // Your login component
import GraduationPlan from "./GraduationPlan"; // We'll create this component

function App() {
  return (
    <Router>
      
      {/* Define routes */}
      <Routes>
        {/* Default route: redirects to Login */}
        <Route path="/" element={<Navigate to="/Login" />} />
        <Route path="/Login" element={<Login />} />
        <Route path="/manual-plan" element={<ManualPlanPage />} />
        <Route path="/Schedule" element={<Schedule />} />
        <Route path="/graduation-plan" element={<GraduationPlan />} />

      </Routes>
    </Router>
  );
}

export default App;