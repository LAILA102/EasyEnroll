// backend/server.js

const express = require("express");
const cors = require("cors");
const fs = require("fs");
const path = require("path");

// Load environment variables
require("dotenv").config();

// Set up OpenAI API client with the new syntax
const { OpenAI } = require("openai");

const openai = new OpenAI({
  apiKey: process.env.OPENAI_API_KEY,
});

// Initialize Express app
const app = express();
app.use(cors());
app.use(express.json());

// Load course data
const coursesData = JSON.parse(
  fs.readFileSync(path.join(__dirname, "data", "courses.json"), "utf8")
);

// Load taken courses data
const takenCoursesData = JSON.parse(
  fs.readFileSync(path.join(__dirname, "data", "takenCourses.json"), "utf8")
);

// Helper functions

// Function to extract course codes from course name
function extractCourseCodes(courseName) {
  const match = courseName.match(/^(.*?) -/);
  if (match) {
    const codePart = match[1].trim();
    const prefixMatch = codePart.match(/^([A-Z]+)\s*(.*)/i);
    if (prefixMatch) {
      const prefix = prefixMatch[1].trim();
      const numbersPart = prefixMatch[2].trim();
      const numbers = numbersPart.split("/").map((num) => num.trim());
      return numbers.map((num) => `${prefix} ${num}`);
    } else {
      return [codePart];
    }
  }
  return [];
}

// Build a course code to course data map
const courseCodeMap = {};
coursesData.forEach((course) => {
  const courseCodes = extractCourseCodes(course["course name"]);
  courseCodes.forEach((code) => {
    courseCodeMap[code] = {
      ...course,
      courseCodes,
    };
  });
});

// Get a set of all required courses
const allRequiredCourses = new Set(Object.keys(courseCodeMap));

// Function to get students' taken courses
function getStudentsTakenCourses(usernames) {
  const studentsTakenCourses = {};
  usernames.forEach((username) => {
    const entries = takenCoursesData.filter(
      (entry) => entry.username === username
    );
    const takenCourses = new Set();
    entries.forEach((entry) => {
      const courseCodes = extractCourseCodes(entry.course);
      courseCodes.forEach((code) => takenCourses.add(code));
    });
    studentsTakenCourses[username] = takenCourses;
  });
  return studentsTakenCourses;
}

// Function to determine remaining courses for each student
function getStudentsRemainingCourses(studentsTakenCourses) {
  const studentsRemainingCourses = {};
  for (const [username, takenCourses] of Object.entries(studentsTakenCourses)) {
    const remainingCourses = new Set(
      [...allRequiredCourses].filter((course) => !takenCourses.has(course))
    );
    studentsRemainingCourses[username] = remainingCourses;
  }
  return studentsRemainingCourses;
}

// Function to generate the graduation plan
async function generateGraduationPlan(usernames) {
  const studentsTakenCourses = getStudentsTakenCourses(usernames);
  const studentsRemainingCourses =
    getStudentsRemainingCourses(studentsTakenCourses);

  // Assuming we have two students
  const [student1, student2] = usernames;
  const student1Taken = studentsTakenCourses[student1];
  const student2Taken = studentsTakenCourses[student2];
  const student1Remaining = studentsRemainingCourses[student1];
  const student2Remaining = studentsRemainingCourses[student2];
  console.log(student1Taken, " ");
  // Courses both students need to take
  const commonCourses = [...student1Remaining].filter((course) =>
    student2Remaining.has(course)
  );

  // Prepare the prompt for OpenAI
  const prompt = `
We have two students, ${student1} and ${student2}, who need to complete the following courses to graduate.

Courses and their prerequisites:

${JSON.stringify(courseCodeMap, null, 2)}

${student1} has taken the following courses:
${[...student1Taken].join(", ")}

${student2} has taken the following courses:
${[...student2Taken].join(", ")}

Both students need to take the following common courses:
${commonCourses.join(", ")}

Please create a graduation plan for both students over the next few semesters, maximizing the number of courses they take together, while ensuring all prerequisites are met. Each semester should have no more than 16 credit per semester.
The most important thing to take care of is the prerequisites, no two courses that are prerequisites to each other can be taken concurrently

Provide the plan in a JSON format like:
{
  "${student1}": {
    "Semester 1": ["Course1", "Course2", ...],
    "Semester 2": ["Course3", "Course4", ...],
    ...
  },
  "${student2}": {
    "Semester 1": ["Course1", "Course2", ...],
    "Semester 2": ["Course3", "Course4", ...],
    ...
  }
}
`;

  // Call the OpenAI API using the new syntax
  const response = await openai.chat.completions.create({
    model: "gpt-3.5-turbo", // Use 'gpt-4' if you have access
    messages: [
      {
        role: "user",
        content: prompt,
      },
    ],
    max_tokens: 3000,
    temperature: 0.7,
  });

  const planText = response.choices[0].message.content.trim();

  // Parse the JSON from the response
  let planJson;
  try {
    const jsonStart = planText.indexOf("{");
    const jsonEnd = planText.lastIndexOf("}") + 1;
    const jsonString = planText.substring(jsonStart, jsonEnd);
    planJson = JSON.parse(jsonString);
  } catch (e) {
    console.error("Failed to parse plan JSON:", e);
    throw new Error("Failed to parse graduation plan");
  }

  return planJson;
}

// API endpoint to generate graduation plans
app.post("/api/generate-plan", async (req, res) => {
  const { students } = req.body; // Array of usernames
  try {
    // Generate the graduation plan
    const plan = await generateGraduationPlan(students);
    res.json({ plan });
  } catch (error) {
    console.error("Error generating plan:", error);
    res.status(500).json({ error: "Failed to generate graduation plan" });
  }
});

// Start the server
const PORT = process.env.PORT || 1900;
app.listen(PORT, () => {
  console.log(`Server listening on port ${PORT}`);
});
