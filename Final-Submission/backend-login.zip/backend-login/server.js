const express = require('express');
const mysql = require('mysql');
const cors = require('cors');
const fs = require('fs'); // Import the file system module

const app = express();

app.use(cors({
    origin: 'http://localhost:3000',  // Allows requests only from this origin
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],  // Specify allowed methods
    allowedHeaders: ['Content-Type', 'Authorization'],  // Specify allowed headers
    credentials: true  // If you need cookies or authentication
}));

app.use(express.json());

// Create a connection for each database
const dbApp = mysql.createConnection({
    host: "localhost",
    user: "Software",
    password: "software123",
    database: "students",
});

const dbBanner = mysql.createConnection({
    host: "localhost",
    user: "Software",
    password: "software123",
    database: "Banner API",
});

app.options('/login', cors());

app.post('/login', (req, res) => {
    const { email, password } = req.body;

    // First, check in the app_students table in the 'students' database
    const sqlApp = "SELECT * FROM app_students WHERE username = ? AND password = ?";
    dbApp.query(sqlApp, [email, password], (err, data) => {
        if (err) return res.json("Error");
        
        if (data.length > 0) {
            // Found in app_students table
            return res.json("Login Successfully");
        } else {
            // Not found in app_students, now check in the 'students' table of 'Banner API' database
            const sqlBanner = "SELECT * FROM students WHERE username = ? AND password = ?";
            dbBanner.query(sqlBanner, [email, password], (err, bannerData) => {
                if (err) return res.json("Error");

                if (bannerData.length > 0) {
                    // Found in Banner API, add to app_students table in 'students' database
                    const insertSql = "INSERT INTO app_students (username, password) VALUES (?, ?)";
                    dbApp.query(insertSql, [email, password], (err, insertResult) => {
                        if (err) return res.json("Error");

                        // Now transfer the student's course information from Banner API to students database
                        const studentID = bannerData[0].ID; // Assuming ID is the field in the Banner API's students table
                        const courseSqlBanner = "SELECT * FROM student_courses WHERE ID = ?";
                        
                        dbBanner.query(courseSqlBanner, [studentID], (err, courseData) => {
                            if (err) return res.json("Error");

                            if (courseData.length > 0) {
                                // Iterate through the courses and insert them into students_courses table in the 'students' database
                                const courseInsertPromises = courseData.map(course => {
                                    return new Promise((resolve, reject) => {
                                        const courseInsertSql = "INSERT INTO student_courses (username, course) VALUES (?, ?)";
                                        dbApp.query(courseInsertSql, [email, course.course], (err, result) => {
                                            if (err) return reject(err);
                                            resolve();
                                        });
                                    });
                                });

                                // Wait for all course inserts to complete
                                Promise.all(courseInsertPromises)
                                    .then(() => {
                                        return res.json("Login Successfully");
                                    })
                                    .catch(() => {
                                        return res.json("Error during course transfer");
                                    });
                            } else {
                                // No courses to transfer, login successful
                                return res.json("Login Successfully");
                            }
                        });
                    });
                } else {
                    // Not found in either table
                    return res.json("No Record");
                }
            });
        }
    });
});

// Route to export student_courses to a JSON file
app.get('/export-student-courses', (req, res) => {
    const sql = "SELECT * FROM student_courses";
    
    dbApp.query(sql, (err, data) => {
        if (err) return res.json("Error fetching data");

        // Write data to a JSON file
        fs.writeFile('student_courses.json', JSON.stringify(data, null, 2), (err) => {
            if (err) return res.json("Error writing to file");

            return res.json("Export successful! File created: student_courses.json");
        });
    });
});

// to download file write http://localhost:8081/export-student-courses*

app.listen(8081, () => {
    console.log("Listening...");
});
